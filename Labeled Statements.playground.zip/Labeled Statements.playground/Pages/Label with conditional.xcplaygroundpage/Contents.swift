//: [Previous](@previous)

import Foundation
let condition = 1 < 2
let condition2 = condition
outer: if condition {
    if condition2 { break outer }
    let foo = 2
}
//: [Next](@next)
