//: [Previous](@previous)

import Foundation

newScope: do {
    print("do")
    break newScope
}
