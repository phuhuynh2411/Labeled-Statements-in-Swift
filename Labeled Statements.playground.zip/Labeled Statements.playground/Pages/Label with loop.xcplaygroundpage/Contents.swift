import UIKit

outer: for i in 0..<3 {
inter: for j in 0..<3 {
    if j == 2 { break outer }
    }
}

outer: for i in 0..<3 {
inter: for j in 0..<3 {
    if j == 2 { continue outer }
    }
}
