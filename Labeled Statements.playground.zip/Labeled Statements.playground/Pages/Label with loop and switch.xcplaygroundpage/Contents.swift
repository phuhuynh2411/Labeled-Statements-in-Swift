//: [Previous](@previous)

import Foundation
let bar: Foo = .bar

outer: for i in 1..<3 {
    switch bar {
    case .bar1: break outer
    case .bar2: print("bar2")
    }
}

enum Foo {
    case bar1
    case bar2
}
//: [Next](@next)
